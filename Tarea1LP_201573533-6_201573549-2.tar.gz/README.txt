Integrantes:
Juan Pablo Jorquera Zapata       201573533-6
Cristian Andres Navarrete Galvez 201573549-2

Instrucciones:
Ejecutar suertex.py